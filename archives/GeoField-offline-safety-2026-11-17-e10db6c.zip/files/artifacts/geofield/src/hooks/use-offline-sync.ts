import { isConnectionUnavailable } from "@/lib/sync-retry";
import { loadStereonets, STEREONETS_UPDATED } from '@/lib/stereonet/storage';
import { syncStereonets } from '@/lib/stereonet/sync-account';
import { confirmDatasetContent } from "@/lib/dataset-confirmation";
import { SyncErrorGrace } from "@/lib/sync-error-grace";
import { syncTracks } from '@/lib/sync-tracks';
import { loadTracks, trackingStatus, TRACKS_UPDATED } from '@/lib/tracks';
import { loadNoteFolders, NOTE_FOLDERS_UPDATED } from "@/lib/note-folders";
import { syncNoteFolders } from "@/lib/sync-note-folders";
import { syncTrips } from "@/lib/sync-trips";
import { loadTrips, TRIPS_UPDATED } from "@/lib/trips";
import { preparePhotoForMeasurement, downloadMeasurementPhotos } from "@/lib/sync-measurement-photos";
import { getStorageAccountId } from "@/lib/storage-account";
import { syncQueuedSample } from "@/lib/sync-sample-queue";
import { prepareSampleUpload, cacheSamplePhotos } from "@/lib/sync-sample-media";
import { syncFieldNotes } from "@/lib/sync-field-notes";
import { loadFieldNotes, FIELD_NOTES_UPDATED } from "@/lib/field-notes";
import { isRetryableSyncError, requiresCloudSignIn, syncRetryDelay } from "@/lib/sync-retry";
import { syncMeasurementRecords } from "@/lib/sync-measurements";
import { useState, useEffect, useCallback, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  requireCloudSyncSession,
  requireFieldNoteAccount,
  useGetCurrentAuthUser,
  createFolder,
  updateFolder,
  deleteFolder,
  restoreFolder,
  createSample,
  getFolders,
  getSamples,
  getGetFoldersQueryKey,
  getGetSamplesQueryKey,
  getSample,
  updateSample,
  deleteSample,
  restoreSample,
  subscribeToAccountDataChanges,
  createStrikeDipMeasurement,
  getStrikeDipMeasurements,
  getStrikeDipMeasurement,
  updateStrikeDipMeasurement,
} from "@workspace/api-client-react";
import {
  getQueue,
  reconcileQueuedDatasetIds,
  removeFromQueue,
  QUEUE_UPDATED_EVENT,
} from "@/lib/offline-queue";
import {
  getPendingLocalDatasets,
  getLocalDatasets,
  reconcileLocalDatasets,
  getLocalDatasetSyncId,
  markLocalDatasetSynced,
  setLocalDatasetSyncStatus,
  LOCAL_DATASETS_UPDATED_EVENT,
  type LocalDataset,
} from "@/lib/local-datasets";
import {
  cacheCloudSamples,
  getCachedCloudSamples,
  markCloudBackfillComplete,
  needsCloudBackfill,
} from "@/lib/cloud-samples";
import {
  loadMeasurements,
  saveMeasurements,
  STRIKE_DIP_UPDATED_EVENT,
  type StrikeDipMeasurement,
} from "@/lib/strike-dip-measurements";

// Layouts can unmount while requests are in flight; serialize across instances.
let syncInFlight = false;

async function syncStrikeDipMeasurements(accountId: string) {
  const check = () => { if (getStorageAccountId() !== accountId) throw new Error("Account changed during sync. Local data has been preserved."); };
  check();
  // Repair links left with a local ID by older versions before comparing revisions.
  saveMeasurements(loadMeasurements(true));
  let count = 0;
  let syncError: unknown;
  try { count = await syncMeasurementRecords<StrikeDipMeasurement>({
    prepare: (item) => preparePhotoForMeasurement(item, accountId),
    load: () => { check(); return loadMeasurements(true); },
    save: (items) => { check(); saveMeasurements(items, { fromSync: true }); },
    get: async (id) => await getStrikeDipMeasurement(id, accountId) as unknown as StrikeDipMeasurement | null,
    list: async () => { await requireFieldNoteAccount(accountId); return await getStrikeDipMeasurements(true, accountId) as unknown as StrikeDipMeasurement[]; },
    create: async (item) => { await requireFieldNoteAccount(accountId); return await createStrikeDipMeasurement({ ...item, createdAt: item.createdAt ?? new Date().toISOString(), updatedAt: item.updatedAt ?? new Date().toISOString() } as any, accountId) as unknown as StrikeDipMeasurement; },
    update: async (item) => { await requireFieldNoteAccount(accountId); return await updateStrikeDipMeasurement(item as any, accountId) as unknown as StrikeDipMeasurement; },
  }); } catch (error) { syncError = error; }
  try { await downloadMeasurementPhotos(accountId); }
  catch (error) { if (syncError) throw new AggregateError([syncError, error], `${syncError instanceof Error ? syncError.message : "Measurement sync failed."} ${error instanceof Error ? error.message : "Photo download failed."}`); throw error; }
  if (syncError) throw syncError;
  return count;
}

function isLocalDatasetId(value: unknown) {
  if (value === null || value === undefined || value === "") return false;
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric < 0;
}

function getSyncableQueue() {
  return getQueue(true).filter(
    (item) =>
      item.payload.fields?.collectionStatus !== "planned" &&
      item.payload.sampleType !== "air",
  );
}

function getPendingSyncItems(accountId = "") {
  const item = (kind: string, id: string | number, name: string, deleted: unknown, datasetId?: string | number | null) => ({
    key: `${kind}:${id}`, kind, name,
    status: deleted ? "Deletion waiting to sync" : "New or edited data waiting to sync",
    detail: Number(datasetId) < 0 ? "Waiting for its project to finish syncing." : "",
  });
  return [
    ...getSyncableQueue().map(record => item("Sample", record.queuedId, record.payload.sampleId || "Unnamed sample", record.deletedAt, record.payload.folderId)),
    ...loadMeasurements(true).filter(record => record.localRevision).map(record => item("Measurement", record.id, record.label?.trim() || (record.measurementType === "lineation" ? "Lineation" : "Strike and Dip"), record.deletedAt, record.datasetId)),
    ...getPendingLocalDatasets().map(record => item("Project", record.id, record.name, record.deletedAt)),
    ...loadTracks(true).filter(record => record.localRevision && record.id !== trackingStatus().activeId).map(record => item("Track", record.id, record.name, record.deletedAt)),
    ...loadStereonets(true).filter(record => record.localRevision).map(record => item("Stereonet", record.id, record.name, record.deletedAt)),
    ...loadTrips(true).filter(record => record.localRevision).map(record => item("Trip", record.id, record.name, record.deletedAt, record.datasetId)),
    ...loadFieldNotes(accountId).filter(record => record.localRevision).map(record => item("Note", record.id, record.title || "Untitled note", record.deletedAt)),
    ...loadNoteFolders(accountId).filter(record => record.localRevision).map(record => item("Note folder", record.id, record.name, record.deletedAt)),
  ];
}
function getPendingSyncCount(accountId = "") { return getPendingSyncItems(accountId).length; }

async function syncLocalDataset(dataset: LocalDataset, checkAccount: () => void, accountId: string) {
  if (dataset.cloudId) {
    if (dataset.deletedAt) await deleteFolder({ id: dataset.cloudId, accountId });
    else {
      const saved = await updateFolder({ id: dataset.cloudId, accountId, data: { name: dataset.name, description: dataset.description } });
      checkAccount();
      confirmDatasetContent(saved, dataset, dataset.cloudId);
      if (dataset.restore) await restoreFolder(dataset.cloudId, accountId);
      else if ((saved as any).deletedAt) throw new Error("This project was deleted on another device. Your offline edit is still saved; restore the project explicitly before syncing it.");
    }
    checkAccount();
    markLocalDatasetSynced(dataset.id, dataset.cloudId, dataset.localRevision);
    return dataset.cloudId;
  }
  setLocalDatasetSyncStatus(dataset.id, "syncing");
  try {
    const id = getLocalDatasetSyncId(dataset.id);
    let created;
    try {
      created = await createFolder({
        id, accountId,
        data: {
          name: dataset.name,
          description: dataset.description || null,
        },
      });
    } catch (error) {
      // A lost response may hide a successful create. Reuse its durable ID.
      const existing = (await getFolders(false, accountId)).find(
        (folder) => String(folder.id) === id,
      );
      if (!existing) throw error;
      created = existing;
      checkAccount();
      if (existing.name !== dataset.name || (existing.description ?? "") !== (dataset.description ?? "")) {
        created = await updateFolder({ id, accountId, data: { name: dataset.name, description: dataset.description } });
      }
    }
    confirmDatasetContent(created, dataset, id);
    const cloudId = String(created.id);
    checkAccount();
    if (dataset.deletedAt) await deleteFolder({ id: cloudId, accountId });
    checkAccount();
    markLocalDatasetSynced(dataset.id, cloudId, dataset.localRevision);
    return cloudId;
  } catch (error) {
    checkAccount();
    setLocalDatasetSyncStatus(dataset.id, "error");
    throw error;
  }
}

export function useOfflineSync() {
  const { data: authData } = useGetCurrentAuthUser();
  const accountId = authData?.user ? String(authData.user.id) : "";
  const queryClient = useQueryClient();
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [connectionUnavailable, setConnectionUnavailable] = useState(false);
  const [pendingItems, setPendingItems] = useState(() => getPendingSyncItems(accountId));
  const queueCount = pendingItems.length;
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncedCount, setSyncedCount] = useState(0);
  const [downloadedCount, setDownloadedCount] = useState(0);
  const [cloudSignInRequired, setCloudSignInRequired] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const [syncProgress, setSyncProgress] = useState<string | null>(null);
  const syncingRef = useRef(false);
  const retryTimer = useRef<ReturnType<typeof setTimeout> | undefined>(
    undefined,
  );
  const retryAttempt = useRef(0);
  const errorGrace = useRef(new SyncErrorGrace());
  const syncRef = useRef<() => Promise<void>>(async () => {});
  const mounted = useRef(true);
  const [retryAt, setRetryAt] = useState<number | null>(null);

  const cancelRetry = useCallback(() => {
    clearTimeout(retryTimer.current);
    retryTimer.current = undefined;
    setRetryAt(null);
  }, []);

  const scheduleRetry = useCallback((verificationDelay?: number) => {
    if (
      !mounted.current ||
      !navigator.onLine ||
      retryTimer.current !== undefined
    )
      return;
    const delay = verificationDelay ?? syncRetryDelay(retryAttempt.current++);
    setRetryAt(Date.now() + delay);
    retryTimer.current = setTimeout(() => {
      retryTimer.current = undefined;
      setRetryAt(null);
      if (mounted.current && navigator.onLine) void syncRef.current();
    }, delay);
  }, []);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      clearTimeout(retryTimer.current);
    };
  }, []);

  useEffect(() => {
    errorGrace.current.reset();
    setConnectionUnavailable(false);
    setLastError(null);
    setCloudSignInRequired(false);
    retryAttempt.current = 0;
    cancelRetry();
  }, [accountId, cancelRetry]);

  const refreshCount = useCallback(() => {
    const next = getPendingSyncItems(accountId);
    setPendingItems(current => JSON.stringify(current) === JSON.stringify(next) ? current : next);
  }, [accountId]);

  useEffect(() => {
    refreshCount();
    window.addEventListener(NOTE_FOLDERS_UPDATED, refreshCount);
    window.addEventListener(FIELD_NOTES_UPDATED, refreshCount);
    window.addEventListener(TRIPS_UPDATED, refreshCount);
    window.addEventListener(TRACKS_UPDATED, refreshCount);
    window.addEventListener(STEREONETS_UPDATED, refreshCount);
    window.addEventListener(STRIKE_DIP_UPDATED_EVENT, refreshCount);
    window.addEventListener(QUEUE_UPDATED_EVENT, refreshCount);
    window.addEventListener(LOCAL_DATASETS_UPDATED_EVENT, refreshCount);
    window.addEventListener("storage", refreshCount);
    return () => {
      window.removeEventListener(NOTE_FOLDERS_UPDATED, refreshCount);
      window.removeEventListener(FIELD_NOTES_UPDATED, refreshCount);
      window.removeEventListener(TRIPS_UPDATED, refreshCount);
      window.removeEventListener(TRACKS_UPDATED, refreshCount);
      window.removeEventListener(STEREONETS_UPDATED, refreshCount);
      window.removeEventListener(STRIKE_DIP_UPDATED_EVENT, refreshCount);
      window.removeEventListener(QUEUE_UPDATED_EVENT, refreshCount);
      window.removeEventListener(LOCAL_DATASETS_UPDATED_EVENT, refreshCount);
      window.removeEventListener("storage", refreshCount);
    };
  }, [refreshCount]);

  const runSync = useCallback(
    async (rebuild: boolean) => {
      if (!accountId || syncingRef.current || !navigator.onLine) return;
      const checkAccount = () => { if (getStorageAccountId() !== accountId) throw new Error("Account changed during sync. Local data has been preserved."); };
      if (syncInFlight) { scheduleRetry(); return; }
      cancelRetry();
      const pendingDatasets = getPendingLocalDatasets();
      syncInFlight = true;
      syncingRef.current = true;
      setIsSyncing(true);

      let failed = false;
      let onlyConnectionFailures = true;
      let retryNeeded = false;
      let authRequired = false;
      let failureMessage: string | null = null;
      const reportFailure = (error: any) => {
        failed = true;
        if (!isConnectionUnavailable(error)) onlyConnectionFailures = false;
        if (requiresCloudSignIn(error)) {
          authRequired = true;
        }
        failureMessage = error?.message || "Could not sync. Your data is still saved on this device.";
        if (isRetryableSyncError(error)) retryNeeded = true;
      };
      try {
        setSyncProgress("Connecting to cloud…");
        await requireFieldNoteAccount(accountId);
        checkAccount();
        // Keep the old cache until a complete replacement has actually downloaded.
        const fullBackfill = rebuild || needsCloudBackfill();
        setSyncProgress(
          fullBackfill
            ? "Preparing full cloud backfill…"
            : "Checking cloud for updates…",
        );
        let synced = 0;

        for (const dataset of pendingDatasets) {
          try {
            await requireFieldNoteAccount(accountId);
            checkAccount();
            await syncLocalDataset(dataset, checkAccount, accountId);
            synced++;
          } catch (error) {
            reportFailure(error);
            refreshCount();
          }
        }

        checkAccount();
        reconcileQueuedDatasetIds(getLocalDatasets(true));
        const queue = getSyncableQueue();
        for (const item of queue) {
          if (
            item.payload.fields?.collectionStatus === "planned" ||
            isLocalDatasetId(item.payload.folderId)
          ) {
            if (isLocalDatasetId(item.payload.folderId)) {
              reportFailure(new Error("A sample is still assigned to a local project. Try syncing again."));
            }
            continue;
          }
          try {
            await requireFieldNoteAccount(accountId);
            checkAccount();
            const changed = await syncQueuedSample(item, {
              load: () => { checkAccount(); return getQueue(true); },
              prepare: (sample) => prepareSampleUpload(sample, accountId),
              create: async (id, payload) => { await requireFieldNoteAccount(accountId); return createSample({ id, data: payload as any, accountId }); },
              update: async (id, payload, baseUpdatedAt) => { await requireFieldNoteAccount(accountId); return updateSample({ id, data: payload as any, accountId, baseUpdatedAt }); },
              get: (id) => getSample(id, accountId),
              delete: async (id) => { await requireFieldNoteAccount(accountId); await deleteSample({ id, accountId }); return getSample(id, accountId); },
              restore: async (id) => { await requireFieldNoteAccount(accountId); await restoreSample(id, accountId); return getSample(id, accountId); },
              cache: (saved) => { checkAccount(); cacheCloudSamples([...getCachedCloudSamples().filter((sample) => String(sample.id) !== String(saved.id)), saved]); },
              remove: (id) => { checkAccount(); removeFromQueue(id); },
            });
            if (changed) retryNeeded = true;
            synced++;
          } catch (error: any) {
            reportFailure(error);
          }
        }

        // Always pull after uploads. A device with nothing pending still needs cloud changes.
        try {
          const results = await Promise.allSettled([
            getSamples(undefined, ({ page, downloaded }) =>
              setSyncProgress(
                `Downloading cloud samples: ${downloaded} received (page ${page})…`,
              ),
              true, accountId,
            ).then(samples => {
              checkAccount();
              const cached = cacheCloudSamples(samples);
              queryClient.setQueryData(getGetSamplesQueryKey(), cached);
              return samples;
            }),
            getFolders(true, accountId).then(folders => {
              checkAccount();
              reconcileLocalDatasets(folders);
              queryClient.setQueryData(getGetFoldersQueryKey(), folders.filter((item: any) => !item.deletedAt));
              return folders;
            }),
            syncStrikeDipMeasurements(accountId),
            syncFieldNotes(accountId),
            syncNoteFolders(accountId),
            syncTrips(accountId),
            syncTracks(accountId),
            syncStereonets(accountId),
          ]);
          // Wait for every operation before releasing the sync lock. An early
          // Promise.all rejection previously left uploads running behind retries.
          checkAccount();
          await requireFieldNoteAccount(accountId);
          const [samplesResult, foldersResult] = results;
          for (const result of results)
            if (result.status === "rejected") reportFailure(result.reason);
          if (samplesResult.status === "fulfilled") {
            const mergedRemote = cacheCloudSamples(samplesResult.value);
            markCloudBackfillComplete(mergedRemote.length);
            setDownloadedCount(mergedRemote.length);
            setTimeout(() => setDownloadedCount(0), 5000);
            queryClient.setQueryData(getGetSamplesQueryKey(), mergedRemote);
            for (const sample of mergedRemote) {
              checkAccount();
              try {
                const cached = await cacheSamplePhotos(sample, partial => {
                  checkAccount();
                  cacheCloudSamples([partial], true);
                });
                checkAccount();
                if (cached !== sample) cacheCloudSamples([cached], true);
              } catch (error) {
                checkAccount();
                reportFailure(error);
              }
            }
          }
          if (foldersResult.status === "fulfilled") {
            reconcileLocalDatasets(foldersResult.value);
            queryClient.setQueryData(
              getGetFoldersQueryKey(),
              foldersResult.value.filter((item: any) => !item.deletedAt),
            );
          }
        } catch (error) {
          reportFailure(error);
        }

        if (synced > 0) {
          setSyncedCount(synced);
          queryClient.invalidateQueries({ queryKey: getGetFoldersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetSamplesQueryKey() });
          setTimeout(() => setSyncedCount(0), 5000);
        }

        checkAccount();
        if (!failed && getPendingSyncCount(accountId) > 0) {
          const remaining = [
            ...getSyncableQueue().map(item => `sample "${item.payload.sampleId || item.queuedId}"`),
            ...loadMeasurements(true).filter(item => item.localRevision).map(item => `measurement "${item.label || item.id}"`),
            ...getPendingLocalDatasets().map(item => `project "${item.name}"`),
            ...loadTracks(true).filter(record => record.localRevision && record.id !== trackingStatus().activeId).map(record => `track "${record.name}"`),
    ...loadTrips(true).filter(item => item.localRevision).map(item => `trip "${item.name}"`),
            ...loadFieldNotes(accountId).filter(item => item.localRevision).map(item => `note "${item.title || item.id}"`),
            ...loadNoteFolders(accountId).filter(item => item.localRevision).map(item => `note folder "${item.name}"`),
          ];
          retryNeeded = true;
          reportFailure(new Error(`Still pending: ${remaining.slice(0, 3).join(", ")}. The latest changes are saved on this device but have not been confirmed by the cloud. Sync will retry automatically. If this continues, check that these records are assigned to an available project.`));
        }

        if (!failed) {
          setConnectionUnavailable(false);
          errorGrace.current.reset();
          setLastError(null);
          setCloudSignInRequired(false);
          retryAttempt.current = 0;
          cancelRetry();
        }
      } catch (error) {
        reportFailure(error);
      } finally {
        syncInFlight = false;
        syncingRef.current = false;
        setIsSyncing(false);
        setSyncProgress(null);
        if (!mounted.current || getStorageAccountId() !== accountId) return;
        refreshCount();
        if (failed && onlyConnectionFailures) {
          // Android WebView can report online even with airplane mode enabled.
          // Keep durable queues and bounded retries; present this as offline.
          setConnectionUnavailable(true);
          errorGrace.current.reset();
          setLastError(null);
          setCloudSignInRequired(false);
        } else if (failed && navigator.onLine) {
          setConnectionUnavailable(false);
          const decision = errorGrace.current.failure(Date.now());
          if (!decision.show) {
            // Verify with a fresh pass, not a timer that displays a stale error.
            scheduleRetry(decision.verifyAfter);
          } else {
            setLastError(failureMessage);
            setCloudSignInRequired(authRequired);
          }
        }
        if (!failed && (loadStereonets(true).some(net => net.localRevision) || loadNoteFolders(accountId).some(folder => folder.localRevision) || loadTrips(true).some((trip) => trip.localRevision) || getPendingLocalDatasets().length > 0 || loadMeasurements(true).some((item) => item.localRevision && !isLocalDatasetId(item.datasetId)) || loadFieldNotes(accountId).some((note) => note.localRevision))) retryNeeded = true;
        if (retryNeeded && !authRequired) scheduleRetry();
      }
    },
    [queryClient, refreshCount, cancelRetry, scheduleRetry, accountId],
  );

  const sync = useCallback(() => runSync(false), [runSync]);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const changed = () => {
      // Sync writes also emit storage events; do not turn a pending failed link
      // into an unbounded immediate retry loop. runSync schedules safe retries.
      if (syncingRef.current) return;
      if (!accountId || getPendingSyncCount(accountId) === 0) return;
      clearTimeout(timer);
      timer = setTimeout(() => { if (navigator.onLine) void sync(); }, 1500);
    };
    window.addEventListener(QUEUE_UPDATED_EVENT, changed);
    window.addEventListener(LOCAL_DATASETS_UPDATED_EVENT, changed);
    window.addEventListener(NOTE_FOLDERS_UPDATED, changed);
    window.addEventListener(FIELD_NOTES_UPDATED, changed);
    window.addEventListener(TRIPS_UPDATED, changed);
    window.addEventListener(TRACKS_UPDATED, changed);
    window.addEventListener(STEREONETS_UPDATED, changed);
    window.addEventListener(STRIKE_DIP_UPDATED_EVENT, changed);
    return () => { clearTimeout(timer); window.removeEventListener(QUEUE_UPDATED_EVENT, changed); window.removeEventListener(LOCAL_DATASETS_UPDATED_EVENT, changed); window.removeEventListener(NOTE_FOLDERS_UPDATED, changed); window.removeEventListener(FIELD_NOTES_UPDATED, changed); window.removeEventListener(TRIPS_UPDATED, changed); window.removeEventListener(TRACKS_UPDATED, changed); window.removeEventListener(STEREONETS_UPDATED, changed); window.removeEventListener(STRIKE_DIP_UPDATED_EVENT, changed); };
  }, [accountId, sync]);
  const rebuildCloudCache = useCallback(() => runSync(true), [runSync]);
  useEffect(() => {
    syncRef.current = sync;
  }, [sync]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setConnectionUnavailable(false);
      sync();
    };
    const handleOffline = () => {
      setIsOnline(false);
      errorGrace.current.reset();
      setLastError(null);
      setCloudSignInRequired(false);
      cancelRetry();
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [sync, cancelRetry]);

  useEffect(() => {
    if (isOnline) sync();
  }, [isOnline, sync]);

  useEffect(() => {
    if (!isOnline) return;
    let refreshTimer: ReturnType<typeof setTimeout> | undefined;
    const refreshAfterCurrentSync = () => {
      if (syncingRef.current) {
        refreshTimer = setTimeout(refreshAfterCurrentSync, 500);
        return;
      }
      sync();
    };
    const unsubscribe = subscribeToAccountDataChanges(() => {
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(refreshAfterCurrentSync, 300);
    });
    return () => {
      clearTimeout(refreshTimer);
      unsubscribe();
    };
  }, [isOnline, sync]);

  useEffect(() => {
    const refreshWhenVisible = () => {
      if (document.visibilityState === "visible" && navigator.onLine) sync();
    };
    document.addEventListener("visibilitychange", refreshWhenVisible);
    return () =>
      document.removeEventListener("visibilitychange", refreshWhenVisible);
  }, [sync]);

  return {
    isOnline: isOnline && !connectionUnavailable,
    queueCount,
    pendingItems,
    isSyncing,
    syncedCount,
    downloadedCount,
    syncProgress,
    lastError,
    cloudSignInRequired,
    retryAt,
    sync,
    rebuildCloudCache,
  };
}
