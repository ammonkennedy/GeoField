import { parseSampleFields, sampleUpdateCondition } from "../sample-fields";
import { createPasswordRecovery } from "../password-recovery";
import { updateDatasetWithAuthorization } from "../dataset-authorization";
import { requestWithCaptionFallback } from "../measurement-caption-request";
import { captureAccountAuthorization } from "../account-authorization";
import { isNetworkError, requireCloudSession } from "../cloud-session";
import { defaultStorage } from "aws-amplify/utils";
import { createOfflineAccount } from "../offline-account";
import { useMutation, useQuery } from "@tanstack/react-query";
import { decodeMeasurementJson, encodeMeasurementJson } from "../measurement-json";
import type { QueryKey, UseMutationOptions, UseQueryOptions, UseQueryResult } from "@tanstack/react-query";
import { Amplify } from "aws-amplify";
import {
  confirmSignUp,
  resetPassword,
  confirmResetPassword,
  resendSignUpCode,
  confirmUserAttribute,
  deleteUser,
  fetchAuthSession,
  fetchUserAttributes,
  getCurrentUser,
  signIn,
  signOut,
  signUp,
  updatePassword,
  updateUserAttribute,
} from "aws-amplify/auth";
import { generateClient } from "aws-amplify/data";
import { getUrl, uploadData } from "aws-amplify/storage";
import outputs from "../../../../amplify_outputs.json";
import type {
  AuthUserEnvelope,
  CreateFolderRequest,
  CreateSampleRequest,
  Folder,
  GetSamplesParams,
  HealthStatus,
  MoveSampleRequest,
  Sample,
  UpdateSampleRequest,
} from "./api.schemas";

Amplify.configure(outputs);
// Bind the web app's local collections to this build's configured user pool.
if (typeof localStorage !== "undefined") {
  try { localStorage.setItem("geofield-active-account-profile", `geofield-account:${outputs.auth.user_pool_client_id}`); } catch { /* Storage failures are surfaced by durable saves. */ }
}


const client: any = generateClient();
const offlineAccount = createOfflineAccount(defaultStorage, `geofield-account:${outputs.auth.user_pool_client_id}`);

/**
 * Local/native builds do not receive Amplify deployment outputs automatically.
 * Keep this check in the shared client so UI surfaces can avoid invoking Auth
 * when no Cognito user pool was included in the build.
 */
export function isAuthConfigured(): boolean {
  const auth = (outputs as any)?.auth;
  return Boolean(auth?.user_pool_id && auth?.user_pool_client_id);
}

export function isStorageConfigured(): boolean {
  return Boolean((outputs as any)?.storage?.bucket_name);
}

export async function uploadSampleMedia(input: {
  sampleId: string;
  localUri: string;
  fileName: string;
  mimeType: string;
  expectedAccountId?: string;
}): Promise<{ storageKey: string; cloudUrl: string }> {
  if (!isStorageConfigured()) {
    throw new Error("Cloud media storage is not configured in this build. Deploy the Amplify backend and rebuild GeoField.");
  }
  const session = await fetchAuthSession();
  if (input.expectedAccountId && (await getCurrentUser()).userId !== input.expectedAccountId) throw new Error("Account changed while syncing photos. Please sync again.");
  const identityId = session.identityId;
  if (!identityId) throw new Error("Sign in before uploading sample media.");
  const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
  // A stable key makes a retry overwrite the same object instead of creating
  // an orphan if connectivity drops after S3 accepts an upload.
  const storageKey = `media/${identityId}/${input.sampleId}/${safeName}`;
  const response = await fetch(input.localUri);
  if (!response.ok) throw new Error(`Could not read media (${response.status}).`);
  const body = await response.blob();
  await uploadData({ path: storageKey, data: body, options: { contentType: input.mimeType } }).result;
  const signed = await getUrl({ path: storageKey, options: { expiresIn: 3600 } });
  return { storageKey, cloudUrl: signed.url.toString() };
}

export async function resolveSampleMediaUrl(storageKey: string): Promise<string> {
  if (!isStorageConfigured()) return "";
  const signed = await getUrl({ path: storageKey, options: { expiresIn: 3600 } });
  return signed.url.toString();
}

type ErrorType<T = unknown> = Error & { data?: T };

type MutationOptions<TData, TVariables> = {
  mutation?: UseMutationOptions<TData, ErrorType<unknown>, TVariables>;
};

type QueryOptions<TData> = {
  query?: Omit<UseQueryOptions<TData, ErrorType<unknown>, TData>, "queryKey" | "queryFn">;
};

function nowIso() {
  return new Date().toISOString();
}

function isActive(record: { deletedAt?: string | null }) {
  return !record.deletedAt;
}


function errorMessage(errors: Array<{ message?: string }> = []) {
  return errors.map((e) => e.message || "Unknown Amplify error").join("; ");
}

function normalizeFolderId(folderId: unknown): string | null | undefined {
  if (folderId === undefined) return undefined;
  if (folderId === null || folderId === "") return null;
  if (typeof folderId === "number" && Number.isNaN(folderId)) return null;
  const value = String(folderId).trim();
  if (!value || value === "NaN" || value === "undefined" || value === "null") return null;
  if (Number(value) < 0) return null;
  return value;
}

export async function requireCloudSyncSession() {
  await requireCloudSession(async () => {
    if (await offlineAccount.isSignedOut()) return false;
    const session = await fetchAuthSession();
    return Boolean(session.tokens?.accessToken);
  });
}

async function accountRequestOptions(expectedAccountId?: string, forceRefresh = false) {
  const accountId = expectedAccountId ?? (await getCurrentUser()).userId;
  return captureAccountAuthorization(accountId, () => fetchAuthSession({ forceRefresh }), () => offlineAccount.isSignedOut());
}

async function hasCurrentUser() {
  if (await offlineAccount.isSignedOut()) return false;
  try {
    await getCurrentUser();
    return true;
  } catch {
    return false;
  }
}

function currentSampleIdFallback(id: string | number | null | undefined): string | number {
  if (id !== undefined && id !== null && String(id) !== "NaN") return id;
  if (typeof globalThis === "undefined" || !("location" in globalThis)) return id as any;
  const parts = globalThis.location.pathname.split("/").filter(Boolean);
  const last = parts[parts.length - 1] || "";
  if (!last || last === "new" || last === "sample") return id as any;
  return last;
}

function cleanFields(fields: unknown) {
  return JSON.parse(JSON.stringify(fields ?? {}));
}

function parseFields(fields: unknown) {
  if (!fields) return {};
  if (typeof fields === "string") {
    try {
      return JSON.parse(fields);
    } catch {
      return {};
    }
  }
  return fields;
}

function serializeFields(fields: unknown) {
  return JSON.stringify(cleanFields(fields));
}


function asFolder(dataset: any): Folder {
  return {
    deletedAt: dataset.deletedAt ?? null,
    id: dataset.id,
    name: dataset.name,
    description: dataset.description ?? null,
    userId: dataset.owner ?? "",
    createdAt: dataset.createdAt ?? nowIso(),
  } as Folder;
}

function asSample(sample: any): Sample {
  return {
    deletedAt: sample.deletedAt ?? null,
    id: sample.id,
    sampleType: sample.sampleType,
    sampleId: sample.sampleId,
    userId: sample.owner ?? "",
    folderId: sample.datasetId ?? null,
    notes: sample.notes ?? null,
    fields: parseSampleFields(sample.fields),
    createdAt: sample.createdAt ?? nowIso(),
    updatedAt: sample.updatedAt ?? sample.createdAt ?? nowIso(),
  } as Sample;
}

async function hydrateSampleMedia(sample: Sample): Promise<Sample> {
  const fields = (sample.fields ?? {}) as Record<string, any>;
  if (!Array.isArray(fields.media)) return sample;
  const media = await Promise.all(fields.media.map(async (item: any) => {
    if (!item?.storageKey?.startsWith("media/")) return item;
    try {
      const cloudUrl = await resolveSampleMediaUrl(item.storageKey);
      return { ...item, cloudUrl, dataUrl: cloudUrl, syncStatus: "synced" };
    } catch {
      return { ...item, cloudUrl: "", dataUrl: "" };
    }
  }));
  const primaryPhoto = media.find((item: any) => item?.kind === "photo" || item?.type === "photo");
  return { ...sample, fields: { ...fields, media, primaryPhoto: primaryPhoto ?? fields.primaryPhoto } } as Sample;
}

function cleanObject<T extends Record<string, any>>(obj: T): T {
  return Object.fromEntries(Object.entries(obj).filter(([, value]) => value !== undefined && value !== null)) as T;
}

export const getHealthCheckUrl = () => "/api/healthz";
export const healthCheck = async (): Promise<HealthStatus> => ({ status: "ok" });
export const getHealthCheckQueryKey = () => ["health"] as const;
export function useHealthCheck<TData = HealthStatus>(options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<unknown>> & { queryKey: QueryKey } {
  const queryKey = getHealthCheckQueryKey();
  const query = useQuery({ queryKey, queryFn: healthCheck, ...(options?.query as any) }) as any;
  return { ...query, queryKey };
}

export const getGetCurrentAuthUserUrl = () => "/auth/current-user";
export const getGetCurrentAuthUserQueryKey = () => ["auth", "current-user"] as const;
async function loadConfirmedAccount() {
  const user = await getCurrentUser();
  const attributes = await fetchUserAttributes().catch(() => ({} as Record<string, string | undefined>));
  return {
    id: user.userId,
    email: attributes.email ?? user.signInDetails?.loginId ?? null,
    firstName: attributes.given_name ?? null,
    lastName: attributes.family_name ?? null,
    profileImageUrl: null,
  };
}

export async function getCurrentAuthUser(): Promise<AuthUserEnvelope> {
  return offlineAccount.resolve(loadConfirmedAccount, typeof navigator !== "undefined" && navigator.onLine === false);
}
export function useGetCurrentAuthUser<TData = AuthUserEnvelope>(options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<unknown>> & { queryKey: QueryKey } {
  const queryKey = getGetCurrentAuthUserQueryKey();
  const query = useQuery({ queryKey, queryFn: getCurrentAuthUser, networkMode: "always", retry: false, ...(options?.query as any) }) as any;
  return { ...query, queryKey };
}

export async function signInUser(input: { email: string; password: string }) {
  if (!isAuthConfigured()) {
    throw new Error("Cloud sign-in is not configured in this build. Continue on this device, or generate amplify_outputs.json before rebuilding.");
  }
  const authenticate = async () => {
    const result = await signIn({ username: input.email.trim(), password: input.password });
    if (result.isSignedIn) await offlineAccount.remember(await loadConfirmedAccount());
    return result;
  };
  try {
    return await authenticate();
  } catch (error: any) {
    if (error?.name === "UserAlreadyAuthenticatedException") {
      // Refresh cloud credentials without treating this retry as explicit logout.
      // If the connection fails, the remembered local account remains available.
      await signOut();
      try {
        return await authenticate();
      } catch (retryError) {
        if (isNetworkError(retryError)) throw new Error("Cannot reach AWS sign-in. Check this device's connection and try again. Your local account and data are still available.");
        throw retryError;
      }
    }
    if (isNetworkError(error)) throw new Error("Cannot reach AWS sign-in. Check this device's connection and try again. Your local account and data are still available.");
    throw error;
  }
}
export async function signUpUser(input: { email: string; password: string }) {
  if (!isAuthConfigured()) {
    throw new Error("Cloud sign-in is not configured in this build. Continue on this device, or generate amplify_outputs.json before rebuilding.");
  }
  return signUp({ username: input.email.trim(), password: input.password, options: { userAttributes: { email: input.email.trim() } } });
}
export async function confirmSignUpUser(input: { email: string; code: string }) {
  return confirmSignUp({ username: input.email.trim(), confirmationCode: input.code.trim() });
}
const passwordRecovery = createPasswordRecovery({ configured: isAuthConfigured, request: resetPassword, confirm: confirmResetPassword });
export const requestPasswordReset = passwordRecovery.request;
export const completePasswordReset = passwordRecovery.complete;
export async function resendConfirmationEmail(input: { email: string }) {
  if (!isAuthConfigured()) throw new Error("Cloud sign-in is not configured in this build.");
  const username = input.email.trim();
  if (!username) throw new Error("Enter the email address used to create your account.");
  return resendSignUpCode({ username });
}

export async function signOutUser() {
  await offlineAccount.clear();
  try {
    await signOut();
  } catch (error) {
    // Local logout must work in the field even if server revocation fails.
    console.warn("Local logout completed; AWS sign-out could not finish.", error);
  }
}

export async function deleteCurrentAccount() {
  if (!(await hasCurrentUser())) throw new Error("Sign in before deleting your account.");

  // Cognito does not cascade account deletion into AppSync records. Remove all
  // owner-scoped data while the user still has permission, then remove the user.
  for (const modelName of ["Sample", "StrikeDipMeasurement", "Dataset", "FieldNote", "Trip"] as const) {
    let nextToken: string | null | undefined;
    do {
      const result = await client.models[modelName].list({ limit: 1000, nextToken });
      if (result.errors?.length) throw new Error(errorMessage(result.errors));
      for (const record of result.data ?? []) {
        const deleted = await client.models[modelName].delete({ id: String(record.id) });
        if (deleted.errors?.length) throw new Error(errorMessage(deleted.errors));
      }
      nextToken = result.nextToken;
    } while (nextToken);
  }
  await deleteUser();
  await offlineAccount.clear();
}

export async function updateAccountEmail(input: { email: string }) {
  return updateUserAttribute({
    userAttribute: {
      attributeKey: "email",
      value: input.email.trim(),
    },
  });
}

export async function confirmAccountEmail(input: { code: string }) {
  return confirmUserAttribute({
    userAttributeKey: "email",
    confirmationCode: input.code.trim(),
  });
}

export async function updateAccountPassword(input: { currentPassword: string; newPassword: string }) {
  return updatePassword({
    oldPassword: input.currentPassword,
    newPassword: input.newPassword,
  });
}

export async function getCurrentAccountToken(): Promise<string> {
  const session = await fetchAuthSession();
  const token = session.tokens?.idToken?.toString();
  if (!token) throw new Error("Sign in before managing billing.");
  return token;
}

/**
 * Notify the active client when another session for the same owner creates,
 * updates, or deletes shared account data. Amplify applies the model's owner
 * authorization to these subscriptions.
 */
export function subscribeToAccountDataChanges(onChange: () => void): () => void {
  const subscriptions: Array<{ unsubscribe: () => void }> = [];
  for (const modelName of ["Sample", "Dataset", "StrikeDipMeasurement", "FieldNote", "NoteFolder", "Trip"] as const) {
    if (!client.models[modelName]) continue; // New models become available when deployment outputs refresh.
    for (const eventName of ["onCreate", "onUpdate", "onDelete"] as const) {
      try {
        const subscription = client.models[modelName][eventName]().subscribe({
          next: onChange,
          error: (error: unknown) => {
            console.warn(`[GeoField sync] ${modelName}.${eventName} subscription unavailable`, error);
          },
        });
        subscriptions.push(subscription);
      } catch (error) {
        console.warn(`[GeoField sync] Could not start ${modelName}.${eventName} subscription`, error);
      }
    }
  }
  return () => subscriptions.forEach((subscription) => subscription.unsubscribe());
}

export const getBeginBrowserLoginUrl = () => "/login";
export const beginBrowserLogin = async () => null;
export const getBeginBrowserLoginQueryKey = () => ["auth", "begin-login"] as const;
export function useBeginBrowserLogin<TData = unknown>(options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<void>> & { queryKey: QueryKey } {
  const queryKey = getBeginBrowserLoginQueryKey();
  const query = useQuery({ queryKey, queryFn: beginBrowserLogin, enabled: false, ...(options?.query as any) }) as any;
  return { ...query, queryKey };
}

export const getGetFoldersQueryKey = () => ["datasets"] as const;
export async function getFolders(includeDeleted = false, expectedAccountId?: string): Promise<Folder[]> {
  if (!(await hasCurrentUser())) return [];
  const readingAccount = (await getCurrentUser()).userId;
  if (expectedAccountId && readingAccount !== expectedAccountId) throw new Error("Account changed before downloading data. Please sync again.");
  const folders: Folder[] = [];
  let nextToken: string | null | undefined;
  do {
    const result = await client.models.Dataset.list({ limit: 1000, nextToken, ...await accountRequestOptions(readingAccount) });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    for (const record of result.data ?? []) {
      if (includeDeleted === true || isActive(record)) {
        folders.push(asFolder(record));
      }
    }
    if ((await getCurrentUser()).userId !== readingAccount) throw new Error("Account changed during download. Please sync again.");
    nextToken = result.nextToken;
  } while (nextToken);
  return folders;
}
export function useGetFolders<TData = Folder[]>(options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<unknown>> & { queryKey: QueryKey } {
  const queryKey = getGetFoldersQueryKey();
  const query = useQuery({ queryKey, queryFn: () => getFolders(), retry: false, ...(options?.query as any) }) as any;
  return { ...query, queryKey };
}

export async function createFolder({ data, id, accountId }: { data: CreateFolderRequest; id?: string; accountId?: string }): Promise<Folder> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before creating projects.");
  const result = await client.models.Dataset.create({ id, name: data.name, description: data.description ?? "", createdAt: nowIso(), updatedAt: nowIso() }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return asFolder(result.data);
}
export function useCreateFolder(options?: MutationOptions<Folder, { data: CreateFolderRequest }>) {
  return useMutation<Folder, ErrorType<unknown>, { data: CreateFolderRequest }>({ mutationFn: createFolder, ...(options?.mutation as any) });
}

export async function updateFolder({ id, data, accountId }: { id: string | number; data: CreateFolderRequest; accountId?: string }): Promise<Folder> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before updating projects.");
  const updatingAccount = accountId ?? (await getCurrentUser()).userId;
  const input = cleanObject({ id: String(id), name: data.name, description: data.description ?? "", updatedAt: nowIso() });
  const result = await updateDatasetWithAuthorization(
    async forceRefresh => client.models.Dataset.update(input, await accountRequestOptions(updatingAccount, forceRefresh)),
    `"${data.name}"`,
  );
  return asFolder(result.data);
}
export function useUpdateFolder(options?: MutationOptions<Folder, { id: string | number; data: CreateFolderRequest }>) {
  return useMutation<Folder, ErrorType<unknown>, { id: string | number; data: CreateFolderRequest }>({ mutationFn: updateFolder, ...(options?.mutation as any) });
}

export async function deleteFolder({ id, accountId }: { id: string | number; accountId?: string }): Promise<void> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before deleting projects.");
  const deletingAccount = accountId ?? (await getCurrentUser()).userId;
  const authorization = await accountRequestOptions(deletingAccount);
  const samples = await getSamples({ folderId: id }, undefined, false, deletingAccount);
  const measurements = (await getStrikeDipMeasurements(false, deletingAccount)).filter((item) => String(item.datasetId) === String(id));
  const detachments = await Promise.all([
    ...samples.map((sample) => client.models.Sample.update({ id: String(sample.id), datasetId: null, updatedAt: nowIso() }, authorization)),
    ...measurements.map((measurement) => client.models.StrikeDipMeasurement.update({ id: measurement.id, datasetId: null, updatedAt: nowIso() }, authorization)),
  ]);
  for (const detached of detachments) {
    if (detached.errors?.length) throw new Error(errorMessage(detached.errors));
    if (!detached.data) throw new Error("Cloud did not confirm that the project contents were preserved. Please retry.");
  }
  const input = { id: String(id), deletedAt: nowIso(), updatedAt: nowIso() };
  await updateDatasetWithAuthorization(
    async forceRefresh => client.models.Dataset.update(input, await accountRequestOptions(deletingAccount, forceRefresh)),
    String(id),
  );
}

export async function getRecentlyDeletedFolders(): Promise<Array<Folder & { deletedAt: string }>> {
  if (!(await hasCurrentUser())) return [];
  const items: Array<Folder & { deletedAt: string }> = [];
  let nextToken: string | null | undefined;
  do {
    const result = await client.models.Dataset.list({ limit: 1000, nextToken });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    for (const record of result.data ?? []) {
      if (!record.deletedAt) continue;
      items.push({ ...asFolder(record), deletedAt: record.deletedAt });
    }
    nextToken = result.nextToken;
  } while (nextToken);
  return items;
}

export async function restoreFolder(id: string | number, accountId?: string): Promise<void> {
  const restoringAccount = accountId ?? (await getCurrentUser()).userId;
  const input = { id: String(id), deletedAt: null, updatedAt: nowIso() };
  await updateDatasetWithAuthorization(
    async forceRefresh => client.models.Dataset.update(input, await accountRequestOptions(restoringAccount, forceRefresh)),
    String(id),
  );
}
export function useDeleteFolder(options?: MutationOptions<void, { id: string | number }>) {
  return useMutation<void, ErrorType<unknown>, { id: string | number }>({ mutationFn: deleteFolder, ...(options?.mutation as any) });
}

export const getGetSamplesQueryKey = (params?: GetSamplesParams) => params?.folderId ? ["samples", String(params.folderId)] as const : ["samples"] as const;
export async function getSamples(
  params?: GetSamplesParams,
  onPage?: (progress: { page: number; downloaded: number }) => void,
  includeDeleted = false,
  expectedAccountId?: string,
): Promise<Sample[]> {
  if (!(await hasCurrentUser())) return [];
  const readingAccount = (await getCurrentUser()).userId;
  if (expectedAccountId && readingAccount !== expectedAccountId) throw new Error("Account changed before downloading data. Please sync again.");
  const samples: Sample[] = [];
  let nextToken: string | null | undefined;
  let page = 0;
  do {
    const result = await client.models.Sample.list({ limit: 1000, nextToken, ...await accountRequestOptions(readingAccount) });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    for (const record of result.data ?? []) {
      if (includeDeleted === true || isActive(record)) {
        samples.push(await hydrateSampleMedia(asSample(record)));
      }
    }
    page += 1;
    onPage?.({ page, downloaded: samples.length });
    if ((await getCurrentUser()).userId !== readingAccount) throw new Error("Account changed during download. Please sync again.");
    nextToken = result.nextToken;
  } while (nextToken);
  if (params?.folderId == null) return samples;
  return samples.filter((sample: any) => String(sample.folderId ?? "") === String(params.folderId));
}
export function useGetSamples<TData = Sample[]>(params?: GetSamplesParams, options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<unknown>> & { queryKey: QueryKey } {
  const queryKey = getGetSamplesQueryKey(params);
  const query = useQuery({ queryKey, queryFn: () => getSamples(params), retry: false, ...(options?.query as any) }) as any;
  return { ...query, queryKey };
}

export const getGetSampleQueryKey = (id: string | number) => ["sample", String(id)] as const;
export async function getSample(id: string | number, accountId?: string): Promise<Sample> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before loading samples.");
  const sampleId = currentSampleIdFallback(id);
  const result = await client.models.Sample.get({ id: String(sampleId) }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  if (!result.data) throw new Error("Sample not found");
  return hydrateSampleMedia(asSample(result.data));
}
export function useGetSample<TData = Sample>(id: string | number, options?: QueryOptions<any>): UseQueryResult<TData, ErrorType<unknown>> & { queryKey: QueryKey } {
  const sampleId = currentSampleIdFallback(id);
  const queryKey = getGetSampleQueryKey(sampleId);
  const queryOptions = { ...((options?.query as any) ?? {}) };
  if (String(id) === "NaN" && String(sampleId) !== "NaN") {
    queryOptions.enabled = true;
  }
  const query = useQuery({ queryKey, queryFn: () => getSample(sampleId), retry: false, ...queryOptions }) as any;
  return { ...query, queryKey };
}

async function createSampleWithInput(input: Record<string, unknown>, accountId?: string) {
  const result = await client.models.Sample.create(input as any, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return asSample(result.data);
}

export async function createSample({ data, id, accountId }: { data: CreateSampleRequest; id?: string; accountId?: string }): Promise<Sample> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before saving samples.");
  const folderId = normalizeFolderId(data.folderId);
  const baseInput = cleanObject({
    id,
    sampleType: (data.sampleType || "rock") as any,
    sampleId: data.sampleId || `sample-${Date.now()}`,
    datasetId: folderId === null ? undefined : folderId,
    notes: data.notes || undefined,
  });

  // Never turn an interrupted/full upload into a successful photo-less record.
  // The caller keeps the durable queue item until the complete write succeeds.
  return createSampleWithInput(cleanObject({
    ...baseInput,
    fields: serializeFields(data.fields),
  }), accountId);
}
export function useCreateSample(options?: MutationOptions<Sample, { data: CreateSampleRequest }>) {
  return useMutation<Sample, ErrorType<unknown>, { data: CreateSampleRequest }>({ mutationFn: createSample, ...(options?.mutation as any) });
}

export async function updateSample({ id, data, accountId, baseUpdatedAt }: { id: string | number; data: UpdateSampleRequest; accountId?: string; baseUpdatedAt?: string }): Promise<Sample> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before updating samples.");
  const folderId = normalizeFolderId(data.folderId);
  const sampleId = currentSampleIdFallback(id);
  const input = { ...cleanObject({
    id: String(sampleId), sampleId: data.sampleId,
    ...(data.folderId === undefined ? {} : { datasetId: folderId }),
    notes: data.notes,
    fields: data.fields === undefined ? undefined : serializeFields(data.fields),
    updatedAt: nowIso(),
  }), ...(data.folderId !== undefined && folderId === null ? { datasetId: null } : {}) };
  const authorization = await accountRequestOptions(accountId);
  if (baseUpdatedAt) {
    // Check the revision at the server's write, not just at the preceding read.
    const response: any = await client.graphql({
      query: `mutation UpdateSampleSafely($input: UpdateSampleInput!, $condition: ModelSampleConditionInput) {
        updateSample(input: $input, condition: $condition) {
          id sampleType sampleId datasetId notes fields owner createdAt updatedAt deletedAt
        }
      }`,
      variables: { input, condition: sampleUpdateCondition(baseUpdatedAt) },
      ...authorization,
    });
    if (response.errors?.length) throw new Error(errorMessage(response.errors));
    if (!response.data?.updateSample) throw new Error("Cloud did not confirm the sample update. The local edit remains pending.");
    return asSample(response.data.updateSample);
  }
  const result = await client.models.Sample.update(input, authorization);
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return asSample(result.data);
}
export function useUpdateSample(options?: MutationOptions<Sample, { id: string | number; data: UpdateSampleRequest }>) {
  return useMutation<Sample, ErrorType<unknown>, { id: string | number; data: UpdateSampleRequest }>({ mutationFn: updateSample, ...(options?.mutation as any) });
}

export async function deleteSample({ id, accountId }: { id: string | number; accountId?: string }): Promise<void> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before deleting samples.");
  const sampleId = currentSampleIdFallback(id);
  const result = await client.models.Sample.update({ id: String(sampleId), deletedAt: nowIso(), updatedAt: nowIso() }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
}

export async function destroySample(id: string | number): Promise<void> {
  if (!(await hasCurrentUser())) throw new Error("Sign in before deleting samples.");
  const result = await client.models.Sample.delete({ id: String(id) });
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
}

export async function getRecentlyDeletedSamples(): Promise<Array<Sample & { deletedAt: string }>> {
  if (!(await hasCurrentUser())) return [];
  const items: Array<Sample & { deletedAt: string }> = [];
  let nextToken: string | null | undefined;
  do {
    const result = await client.models.Sample.list({ limit: 1000, nextToken });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    for (const record of result.data ?? []) {
      if (!record.deletedAt) continue;
      items.push({ ...asSample(record), deletedAt: record.deletedAt });
    }
    nextToken = result.nextToken;
  } while (nextToken);
  return items;
}

export async function restoreSample(id: string | number, accountId?: string): Promise<void> {
  const result = await client.models.Sample.update({ id: String(id), deletedAt: null, updatedAt: nowIso() }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
}
export function useDeleteSample(options?: MutationOptions<void, { id: string | number }>) {
  return useMutation<void, ErrorType<unknown>, { id: string | number }>({ mutationFn: deleteSample, ...(options?.mutation as any) });
}

export async function moveSample({ id, data }: { id: string | number; data: MoveSampleRequest }): Promise<Sample> {
  return updateSample({ id, data: { folderId: data.folderId } });
}

export interface CloudStrikeDipMeasurement {
  photoKey?: string | null;
  photoCaption?: string;
  deletedAt?: string | null;
  id: string;
  measurementType?: "plane" | "lineation";
  datasetId?: string | null;
  label: string;
  strike: string;
  dip: string;
  dipDir: string;
  strikeDegrees?: number;
  dipDegrees?: number;
  dipDirectionDegrees?: number;
  trendDegrees?: number;
  plungeDegrees?: number;
  lineVector?: unknown;
  convention?: string;
  northReference?: string;
  compassAccuracy?: number;
  magneticHeading?: number;
  trueHeading?: number;
  magneticDeclination?: number;
  referenceFrame?: string;
  rawMagneticStrikeDegrees?: number;
  orientationQuaternion?: unknown;
  planeNormal?: unknown;
  quality?: string;
  location: string;
  latitude?: number;
  longitude?: number;
  gpsAccuracy?: number;
  elevation?: number | null;
  elevationAccuracy?: number | null;
  utmZone?: string;
  utmEasting?: number;
  utmNorthing?: number;
  date: string;
  featureType: string;
  rockLayerType?: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

function asStrikeDipMeasurement(record: any): CloudStrikeDipMeasurement {
  return {
    id: String(record.id), photoKey: record.photoKey ?? null, photoCaption: record.photoCaption ?? "", measurementType: record.measurementType === "lineation" ? "lineation" : "plane", datasetId: record.datasetId ?? null,
    label: record.label ?? "", strike: record.strike ?? "", dip: record.dip ?? "", dipDir: record.dipDir ?? "",
    strikeDegrees: record.strikeDegrees ?? undefined, dipDegrees: record.dipDegrees ?? undefined,
    dipDirectionDegrees: record.dipDirectionDegrees ?? undefined, convention: record.convention ?? undefined,
    trendDegrees: record.trendDegrees ?? undefined, plungeDegrees: record.plungeDegrees ?? undefined,
    lineVector: decodeMeasurementJson(record.lineVector),
    northReference: record.northReference ?? undefined, compassAccuracy: record.compassAccuracy ?? undefined,
    magneticHeading: record.magneticHeading ?? undefined, trueHeading: record.trueHeading ?? undefined,
    magneticDeclination: record.magneticDeclination ?? undefined, referenceFrame: record.referenceFrame ?? undefined,
    rawMagneticStrikeDegrees: record.rawMagneticStrikeDegrees ?? undefined,
    orientationQuaternion: decodeMeasurementJson(record.orientationQuaternion), planeNormal: decodeMeasurementJson(record.planeNormal),
    quality: record.quality ?? undefined, location: record.location ?? "", latitude: record.latitude ?? undefined,
    elevation: record.elevation ?? null, elevationAccuracy: record.elevationAccuracy ?? null,
    longitude: record.longitude ?? undefined, gpsAccuracy: record.gpsAccuracy ?? undefined, utmZone: record.utmZone ?? undefined,
    utmEasting: record.utmEasting ?? undefined, utmNorthing: record.utmNorthing ?? undefined,
    date: record.measuredAt ?? record.date ?? "", featureType: record.featureType ?? "", rockLayerType: record.rockLayerType ?? "", notes: record.notes ?? "",
    deletedAt: record.deletedAt ?? null, createdAt: record.createdAt ?? nowIso(), updatedAt: record.updatedAt ?? record.createdAt ?? nowIso(),
  };
}

function strikeDipInput(data: Partial<CloudStrikeDipMeasurement>) {
  // Deletion must not depend on stale/invalid measurement fields or a removed dataset.
  if (data.deletedAt && Object.keys(data).every(key => ["id", "deletedAt", "createdAt", "updatedAt"].includes(key))) return { deletedAt: data.deletedAt };
  const input = cleanObject({
    photoCaption: data.photoCaption,
    measurementType: data.measurementType ?? "plane", datasetId: normalizeFolderId(data.datasetId) ?? undefined, label: data.label, strike: data.strike, dip: data.dip,
    dipDir: data.dipDir, strikeDegrees: data.strikeDegrees, dipDegrees: data.dipDegrees,
    trendDegrees: data.trendDegrees, plungeDegrees: data.plungeDegrees, lineVector: encodeMeasurementJson(data.lineVector),
    dipDirectionDegrees: data.dipDirectionDegrees, convention: data.convention, northReference: data.northReference,
    compassAccuracy: data.compassAccuracy, magneticHeading: data.magneticHeading, trueHeading: data.trueHeading,
    magneticDeclination: data.magneticDeclination, referenceFrame: data.referenceFrame,
    rawMagneticStrikeDegrees: data.rawMagneticStrikeDegrees, orientationQuaternion: encodeMeasurementJson(data.orientationQuaternion),
    planeNormal: encodeMeasurementJson(data.planeNormal), quality: data.quality, location: data.location, latitude: data.latitude,
    elevation: data.elevation, elevationAccuracy: data.elevationAccuracy,
    longitude: data.longitude, gpsAccuracy: data.gpsAccuracy, utmZone: data.utmZone,
    utmEasting: data.utmEasting, utmNorthing: data.utmNorthing, date: data.date?.slice(0, 10), measuredAt: data.date,
    featureType: data.featureType, rockLayerType: data.rockLayerType, notes: data.notes,
  });
  const nullableHeight = {
    ...(data.photoKey !== undefined ? { photoKey: data.photoKey } : {}),
    deletedAt: data.deletedAt ?? null,
    ...(data.elevation === null ? { elevation: null } : {}),
    ...(data.elevationAccuracy === null ? { elevationAccuracy: null } : {}),
  };
  // GraphQL needs explicit null to clear an assignment; cleanObject drops nulls.
  return data.datasetId === null || data.datasetId === ""
    ? { ...input, ...nullableHeight, datasetId: null }
    : { ...input, ...nullableHeight };
}

// Explicit selection includes the new caption field after the backend is deployed,
// even before a local Xcode checkout has refreshed generated model introspection.
async function measurementRequest(kind: "list" | "get" | "create" | "update", input: Record<string, unknown>, accountId?: string) {
  const fields = outputs.data.model_introspection.models.StrikeDipMeasurement.fields;
  const selection = [...new Set([...Object.entries(fields).filter(([, field]) => typeof field.type === "string").map(([name]) => name), "photoCaption"])].join(" ");
  let query: string;
  let variables: Record<string, unknown>;
  const operation = kind === "list" ? "listStrikeDipMeasurements" : `${kind}StrikeDipMeasurement`;
  if (kind === "list") {
    query = `query ReadMeasurements($nextToken: String) { ${operation}(limit: 1000, nextToken: $nextToken) { items { ${selection} } nextToken } }`;
    variables = { nextToken: input.nextToken ?? null };
  } else if (kind === "get") {
    query = `query ReadMeasurement($id: ID!) { ${operation}(id: $id) { ${selection} } }`;
    variables = { id: input.id };
  } else {
    const inputType = kind === "create" ? "CreateStrikeDipMeasurementInput" : "UpdateStrikeDipMeasurementInput";
    query = `mutation SaveMeasurement($input: ${inputType}!) { ${operation}(input: $input) { ${selection} } }`;
    variables = { input };
  }
  const result = await requestWithCaptionFallback(request => client.graphql(request), { query, variables, ...await accountRequestOptions(accountId) });
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  const value = result.data?.[operation];
  if (kind !== "get" && !value) throw new Error("Cloud did not confirm the measurement request. Local data is preserved.");
  return kind === "list" ? { data: value.items, nextToken: value.nextToken, errors: undefined } : { data: value, errors: undefined };
}

export async function getStrikeDipMeasurements(includeDeleted = false, expectedAccountId?: string): Promise<CloudStrikeDipMeasurement[]> {
  await requireCloudSyncSession();
  const readingAccount = (await getCurrentUser()).userId;
  if (expectedAccountId && readingAccount !== expectedAccountId) throw new Error("Account changed before downloading data. Please sync again.");
  const items: CloudStrikeDipMeasurement[] = [];
  let nextToken: string | null | undefined;
  do {
    const result = await measurementRequest("list", { nextToken }, readingAccount);
    for (const record of result.data ?? []) if (includeDeleted === true || !record.deletedAt) items.push(asStrikeDipMeasurement(record));
    if ((await getCurrentUser()).userId !== readingAccount) throw new Error("Account changed during download. Please sync again.");
    nextToken = result.nextToken;
  } while (nextToken);
  return items;
}

export async function getStrikeDipMeasurement(id: string, accountId?: string): Promise<CloudStrikeDipMeasurement | null> {
  const result = await measurementRequest("get", { id }, accountId);
  return result.data ? asStrikeDipMeasurement(result.data) : null;
}

export async function createStrikeDipMeasurement(data: CloudStrikeDipMeasurement, accountId?: string): Promise<CloudStrikeDipMeasurement> {
  await requireCloudSyncSession();
  const result = await measurementRequest("create", { id: data.id, ...strikeDipInput(data), createdAt: data.createdAt }, accountId);
  return asStrikeDipMeasurement(result.data);
}

export async function updateStrikeDipMeasurement(data: CloudStrikeDipMeasurement, accountId?: string): Promise<CloudStrikeDipMeasurement> {
  await requireCloudSyncSession();
  const result = await measurementRequest("update", { id: data.id, ...strikeDipInput(data) }, accountId);
  return asStrikeDipMeasurement(result.data);
}
export function useMoveSample(options?: MutationOptions<Sample, { id: string | number; data: MoveSampleRequest }>) {
  return useMutation<Sample, ErrorType<unknown>, { id: string | number; data: MoveSampleRequest }>({ mutationFn: moveSample, ...(options?.mutation as any) });
}


export interface CloudFieldNote {
  id: string;
  title: string;
  body: string;
  photos: Array<{ id: string; fileName: string; cloudKey: string; caption?: string; kind?: "photo" | "video"; mimeType?: string }>;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}
function asFieldNote(record: any): CloudFieldNote {
  if (!record?.id) throw new Error("Cloud did not confirm the field note.");
  const photos = parseFields(record.photos);
  return { id: String(record.id), title: record.title ?? "", body: record.body ?? "", photos: Array.isArray(photos) ? photos : [], createdAt: record.createdAt, updatedAt: record.updatedAt, deletedAt: record.deletedAt ?? null };
}
export async function requireFieldNoteAccount(accountId: string) {
  await requireCloudSyncSession();
  if ((await getCurrentUser()).userId !== accountId) throw new Error("Account changed while syncing notes. Please sync again.");
}
export async function getFieldNotes(accountId: string): Promise<CloudFieldNote[]> {
  await requireFieldNoteAccount(accountId);
  const notes: CloudFieldNote[] = [];
  let nextToken: string | undefined;
  do {
    const result = await client.models.FieldNote.list({ limit: 500, nextToken, ...await accountRequestOptions(accountId) });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    await requireFieldNoteAccount(accountId);
    notes.push(...(result.data ?? []).map(asFieldNote));
    nextToken = result.nextToken;
  } while (nextToken);
  return notes;
}
export async function getFieldNote(id: string, accountId: string): Promise<CloudFieldNote | null> {
  const result = await client.models.FieldNote.get({ id }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return result.data ? asFieldNote(result.data) : null;
}

export async function saveCloudFieldNote(note: CloudFieldNote, exists: boolean, accountId: string): Promise<CloudFieldNote> {
  await requireFieldNoteAccount(accountId);
  const input = { id: note.id, title: note.title, body: note.body, photos: JSON.stringify(note.photos), createdAt: note.createdAt, deletedAt: note.deletedAt ?? null };
  const result = await client.models.FieldNote[exists ? "update" : "create"](input, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return asFieldNote(result.data);
}

// Explicit operations let older app builds keep their existing note model unchanged.
// The NoteFolder backend model must be deployed before releasing this client.
export interface CloudNoteFolder {
  id: string;
  name: string;
  noteIds: string[];
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}
function asNoteFolder(record: any): CloudNoteFolder {
  if (!record?.id || typeof record.name !== "string") throw new Error("Cloud did not confirm the note folder.");
  const ids = typeof record.noteIds === "string" ? JSON.parse(record.noteIds) : record.noteIds ?? [];
  if (!Array.isArray(ids) || ids.some((id: unknown) => typeof id !== "string")) throw new Error("Cloud folder membership could not be read. Your local folder is preserved.");
  return { id: record.id, name: record.name, noteIds: [...new Set<string>(ids)], createdAt: record.createdAt, updatedAt: record.updatedAt, deletedAt: record.deletedAt ?? null };
}
const noteFolderSelection = "id name noteIds createdAt updatedAt deletedAt";
async function noteFolderRequest(query: string, variables: Record<string, unknown>, accountId: string): Promise<any> {
  await requireFieldNoteAccount(accountId);
  const options = await accountRequestOptions(accountId);
  try {
    const result = await client.graphql({ query, variables, ...options });
    await requireFieldNoteAccount(accountId);
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    return result.data;
  } catch (error: any) {
    const message = error?.errors ? errorMessage(error.errors) : error?.message || "Note folders could not sync.";
    if (/NoteFolder|noteFolder/.test(message) && /undefined|not defined|Unknown|does not exist/i.test(message)) {
      throw new Error("Note folder cloud support needs a server update. Your folders and notes remain saved on this device.");
    }
    throw new Error(message);
  }
}
export async function getCloudNoteFolders(accountId: string): Promise<CloudNoteFolder[]> {
  const folders: CloudNoteFolder[] = [];
  let nextToken: string | null = null;
  do {
    const data = await noteFolderRequest(`query ListNoteFolders($nextToken: String) { listNoteFolders(limit: 500, nextToken: $nextToken) { items { ${noteFolderSelection} } nextToken } }`, { nextToken }, accountId);
    if (!data?.listNoteFolders || !Array.isArray(data.listNoteFolders.items)) throw new Error("Cloud note folders could not be read.");
    folders.push(...data.listNoteFolders.items.filter(Boolean).map(asNoteFolder));
    nextToken = data.listNoteFolders.nextToken;
  } while (nextToken);
  return folders;
}
export async function getCloudNoteFolder(id: string, accountId: string): Promise<CloudNoteFolder | null> {
  const data = await noteFolderRequest(`query GetNoteFolder($id: ID!) { getNoteFolder(id: $id) { ${noteFolderSelection} } }`, { id }, accountId);
  return data?.getNoteFolder ? asNoteFolder(data.getNoteFolder) : null;
}
export async function saveCloudNoteFolder(folder: CloudNoteFolder, exists: boolean, accountId: string): Promise<CloudNoteFolder> {
  const operation = exists ? "updateNoteFolder" : "createNoteFolder";
  const inputType = exists ? "UpdateNoteFolderInput" : "CreateNoteFolderInput";
  const input = { id: folder.id, name: folder.name, noteIds: JSON.stringify(folder.noteIds), createdAt: folder.createdAt, deletedAt: folder.deletedAt ?? null };
  const data = await noteFolderRequest(`mutation SaveNoteFolder($input: ${inputType}!) { ${operation}(input: $input) { ${noteFolderSelection} } }`, { input }, accountId);
  return asNoteFolder(data?.[operation]);
}

export interface CloudTrip {
  id: string;
  name: string;
  notes: string;
  sites: Array<{ id: string; name: string; description: string; lat: number; lng: number; addedAt: string; sampleType?: "water" | "rock" | "soil_sand" | "air" | "other"; collectedAt?: string }>;
  datasetId?: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}
function asTrip(record: any): CloudTrip {
  if (!record?.id) throw new Error("Cloud did not confirm the trip.");
  const sites = parseFields(record.sites);
  if (!Array.isArray(sites)) throw new Error("Cloud trip sites could not be read. Your local trip is preserved.");
  return { id: String(record.id), name: record.name, notes: record.notes ?? "", sites, datasetId: record.datasetId ?? null, createdAt: record.createdAt, updatedAt: record.updatedAt, deletedAt: record.deletedAt ?? null };
}
export async function getCloudTrips(accountId: string): Promise<CloudTrip[]> {
  await requireFieldNoteAccount(accountId);
  const trips: CloudTrip[] = [];
  let nextToken: string | undefined;
  do {
    const result = await client.models.Trip.list({ limit: 500, nextToken, ...await accountRequestOptions(accountId) });
    if (result.errors?.length) throw new Error(errorMessage(result.errors));
    await requireFieldNoteAccount(accountId);
    trips.push(...(result.data ?? []).map(asTrip));
    nextToken = result.nextToken;
  } while (nextToken);
  return trips;
}
export async function getCloudTrip(id: string, accountId: string): Promise<CloudTrip | null> {
  const result = await client.models.Trip.get({ id }, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return result.data ? asTrip(result.data) : null;
}
export async function saveCloudTrip(trip: CloudTrip, exists: boolean, accountId: string): Promise<CloudTrip> {
  const input = { id: trip.id, name: trip.name, notes: trip.notes, sites: JSON.stringify(trip.sites), datasetId: trip.datasetId ?? null, createdAt: trip.createdAt, deletedAt: trip.deletedAt ?? null };
  const result = await client.models.Trip[exists ? "update" : "create"](input, await accountRequestOptions(accountId));
  if (result.errors?.length) throw new Error(errorMessage(result.errors));
  return asTrip(result.data);
}
