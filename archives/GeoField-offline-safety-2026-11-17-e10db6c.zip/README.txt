GeoField sample safety and multi-day offline changes
Commit: e10db6c816254ea6f600ac884b1506a87e3ecafa
Contains 16 changed source/test/documentation files plus a Git patch.
This is a source-change archive, not an Android/iOS installable build or user-data backup.
No signing credentials or Android Studio settings are included.
